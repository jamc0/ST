<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentoDetalle extends Model
{
    protected $table='documentosdetalles';
    public $primaryKey ='id';
}
